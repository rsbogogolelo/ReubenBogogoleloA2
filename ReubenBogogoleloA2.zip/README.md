"""
Name: Reuben Bogogolelo
Date: 11 January 2017 - 04 February 2017
Brief Project Description:
This project is an upgrade version of Assignment 1.
Just by giving the program overview; the program has 4 core functions as main.py, booklists.py, book.py and app.kv.
But in addition, the test.py files for booklists.py and book.py has been created to test and validate the functiontionalities
of the same. As demonstrated by the codes functionalities, the program will first load the "List of Required Books" which is a
default or welcome screen. Once the button ("List of Required Books") is clicked, it will mark the book as completed and it will
automatically sends the book to the "List completed". The "List Completed" will show all completed books by titles. The full details
of the book will only show when the title is clicked and the details will show on the status bar below. The program wil aloow the
user to add new books they wish to. In this case, the user will be prompted to put all the details of the book as provided.
The program will not allow the user to proceed until all the fields are populated with relavant input type. For example, the number
of pages will only aloow the integer numbers. Once done, the user will click the "Add Item" to add the books in the list and the fields
will clear once added. If the user wants to clear the information, say maybe they want to achange to change their minds, the "Clear
button has been created to do that. Once the program exits, the csv file will be updated with any changes.

GitHub URL: https://github.com/rsbogogolelo/ReubenBogogoleloA2
"""


## 1. How long did the entire project (assignment 2) take you?
It took me 4 weeks to complete
Note: You may like to use the WakaTime plugin, which tracks exactly how long you spend in code. See http://wakatime.com (but note that the free version only has a 7-day history)

## 2. What are you most satisfied with?
I am satisfied with the integration of files and the the coding experience I have gained throughout the period. The construction of Methods and Objects and how they work within the
Class was really a good experience.

## 3. What are you least satisfied with?
The import of some kivy files which I did not fully understand how they work.

## 4. What worked well in your development process?
The loading of the csv file and the construction of GUI kivy layout. The testing of book.py and booklist.py was so amazing.
 The calling of methods in the main function was a success.

## 5. What about your process could be improved the next time you do a project like this?
I need to practice and work hard on codes more especially the kivy part. I also need to approach it with a relaxed steady mind as
this will allow me to plan well.

## 6. Describe what resources you used and how you used them.
- I consulted with the past practical exercises by redoing some of the key tasks that were relevant to my assignment
- I consulted with my friends and tuitor where I got stuck
- I also went through www.stackoverflow.com site by practicing some of their given demos on my own.

## 7. Describe the main challenges or obstacles you faced and how you overcame them.
Challenges were as follows;
- At first I did not know where to start as the exercises was more complex. But I decided to do sit in some bits as I
  tested every step till I finish.
- The program did not run at some point after putting more efforts to it. As such, I had to break and ensured that my
  mind is cleared before debugging for problems/errors.
- Some of the codes did not make sense to me but had to ask my colleagues and the lecturer/tuitor. In addition, I used
  the online tutorials which were also of great help.
