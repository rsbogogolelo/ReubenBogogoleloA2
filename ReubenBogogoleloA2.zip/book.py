# create your simple Book class in this file


class Book:

    def __init__(self,title="",author = "",pages = 0,status = ""):
        self.title = title
        self.author = author
        self.pages = pages
        self.status = status

        #self.bookdata = [self.title,self.author,self.pages,self.status]
        #self.bookdata

        return


    def __str__(self):#To return the message in the book object
        return "{} by {}, total pages is {}".format(self.title, self.author, self.pages)


    def mark_as_complete(self,status):#Mark the book as completed when clicking the button as referenced in the main.py file
        if status=="r":
            self.status = "c"
            return  True
        elif status =="c":
            return False

    def book_size(self,pages):#Method is used to determine the book size and it will show by colors whether the book is long or not
        if int(pages) >= 500:
            return True
        else:
            return False

