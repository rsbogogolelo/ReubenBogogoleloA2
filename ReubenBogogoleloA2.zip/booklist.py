# create your BookList class in this file


from book import Book
from operator import attrgetter

FILENAME = "books.csv"
class BookList():

    def load_books(self,filename=""):
        #The function loads the book.csv file and then interpreted in the list of Book objects
        file_pointer = open(filename, "r")
        for index, data in enumerate(file_pointer.readlines()):
            #print(len(file_pointer.readlines()))
            data = data.strip()
            datum = data.split(",")
            each_book = Book(datum[0],datum[1],datum[2],datum[3])
            self.booklists.append(each_book)
        #self.data.sort(key=attrgetter(1, 2))
        file_pointer.close()
        return self.booklists


    def __init__(self):
        booklists=[]
        self.booklists = booklists

    def __getitem__(self, item):
        #This method is used to refrence the booklists based on the index(booklists being the list of Book objects) in the main.py
        return self.booklists[item]

    def add_book(self,title,author,pages):
        #This function is for adding the object to the list of Book objects
        status = "r"
        book = Book(title, author, pages, status)
        self.booklists.append(book)
        return book

    def get_total_pages_for_required_books(self):
    #This function is for counting the required page in order to display the message for total required page
        required_booklists_pages = 0#initiate the total required booklist pages
        for i in range(len(self.booklists)):
            if self.booklists[i].status == 'r':#iterate the procedure based on the number of items in the booklists (len(self.booklists)) in the certain conditions(status in the Book object is completed)
                required_booklists_pages += (int(self.booklists[i].pages))#adding the pages based on the Book objects that is required
        total_pages_for_required_books = "Total pages to read: {}".format(required_booklists_pages)
        return total_pages_for_required_books


    def get_total_pages_for_completed_books(self):
    #This method is for counting and displaying the completed pages read
        completed_booklists_pages = 0#initiate the total completed booklist pages
        for counts in range(len(self.booklists)):
            if self.booklists[counts].status == 'c':
                completed_booklists_pages += (int(self.booklists[counts].pages))#adding pages based on the Book objects completed
        total_pages_for_completed_books = "Total pages completed: {}".format(completed_booklists_pages)
        return total_pages_for_completed_books


    def saving_books(self,filename=""):
        #This function is to save the book list changes to the book.csv file
        output_file = open(filename, "w")
        for book in range(len(self.booklists)):
            book = "{},{},{},{}\n".format(self.booklists[book].title,self.booklists[book].author,self.booklists[book].pages,self.booklists[book].status)
            output_file.write(book)
        output_file.close()


    def sort_books(self):
        #The function will sort the Book objects based on the author and pages
        sort = self.booklists.sort(key=attrgetter('author','pages'))
        return sort

