"""
Name: Reuben Bogogolelo
Date: 11 January 2017 - 04 February 2017
Brief Project Description:
This project is an upgrade version of Assignment 1.
Just by giving the program overview; the program has 4 core functions as main.py, booklists.py, book.py and app.kv.
But in addition, the test.py files for booklists.py and book.py has been created to test and validate the functiontionalities
of the same. As demonstrated by the codes functionalities, the program will first load the "List of Required Books" which is a
default or welcome screen. Once the button ("List of Required Books") is clicked, it will mark the book as completed and it will
automatically sends the book to the "List completed". The "List Completed" will show all completed books by titles. The full details
of the book will only show when the title is clicked and the details will show on the status bar below. The program wil aloow the
user to add new books they wish to. In this case, the user will be prompted to put all the details of the book as provided.
The program will not allow the user to proceed until all the fields are populated with relavant input type. For example, the number
of pages will only aloow the integer numbers. Once done, the user will click the "Add Item" to add the books in the list and the fields
will clear once added. If the user wants to clear the information, say maybe they want to achange to change their minds, the "Clear
button has been created to do that. Once the program exits, the csv file will be updated with any changes.

GitHub URL: https://github.com/rsbogogolelo/ReubenBogogoleloA2
"""

from kivy.app import App
from kivy.lang import Builder
from book import Book
from kivy.uix.button import Button
from kivy.properties import StringProperty
from operator import itemgetter
from booklist import BookList


class ReadingListApp(App):
    def __init__(self, **kwargs):
        super(ReadingListApp, self).__init__(**kwargs)
        book_lists = BookList()  # calling the BookList class
        book_object = Book()  # calling the Book class
        self.book_lists = book_lists
        self.book_object = book_object
        self.book_lists.load_books("books.csv") #loading the book in order to get the list of the Book objects

    def on_start(self):#This function is used for initialise the program when the user start to run the it
         self.create_widgets(input_parameter='required')
         self.root.ids.required_book_button.state = 'down'  #state is to determine whether the button is on the pressed state or not
         self.root.ids.completed_book_button.state = 'normal'

    def create_widgets(self, input_parameter):#This function is used for creating the book button in the entriesBox widget
        self.clear_books()

        if input_parameter == 'required':
            for book in range(len(self.book_lists.booklists)):
                if self.book_lists[book].status=='r':
                    temp_button = Button(text=self.book_lists[book].title)#text that will be generated on the button
                    temp_button.bind(on_release=self.click_list_required)
                    page_check=self.book_object.book_size(self.book_lists[book].pages)#to determine the background color for the button, which is by checking the book object pages
                    if page_check == True:
                        temp_button.background_color= 0, 1, 1, 1#it will show blue color when the book is long

                    else:
                        temp_button.background_color=0.8, 0.8, 0, 1#it will show yellow color when the book is short
                    self.root.ids.entriesBox.add_widget(temp_button)
            total_required_pages=self.book_lists.get_total_pages_for_required_books()#calling the method to display total required pages from the BookList() class
            self.root.ids.bookPages.text=total_required_pages
            self.root.ids.output_label.text = 'Click books to mark as completed'#Initialise the message when clicking "Required books"

        elif input_parameter == 'completed': #it wil create a button for completed books
            #self.root.ids.entriesBox.clear_widgets()
            for book in range(len(self.book_lists.booklists)):
                if self.book_lists[book].status=='c':
                   temp_button = Button(text=self.book_lists[book].title)
                   temp_button.bind(on_release=self.click_list_completed)
                   temp_button.background_color = 0.37, 0.37, 0.37, 1
                   self.root.ids.entriesBox.add_widget(temp_button)

            total_completed_pages = self.book_lists.get_total_pages_for_completed_books()
            self.root.ids.output_label.text = "Click book to show the description"#Initialise the message when clicking "Completed books
            self.root.ids.bookPages.text =total_completed_pages

    def press_required_books(self):#the function runs when "Required books" is pressed
        self.create_widgets(input_parameter='required')#to get the required book buttons
        self.root.ids.required_book_button.state = 'down'
        self.root.ids.completed_book_button.state = 'normal'

    def press_completed_books(self):#the function will run when "Completed books" is pressed
        self.create_widgets(input_parameter='completed')#to get the completed book buttons
        self.root.ids.required_book_button.state = 'normal'
        self.root.ids.completed_book_button.state = 'down'

    def add_books(self,title_text_input, author_text_input, pages_text_input):
        #This function is to add books on the list of Book object, which occurs when "Add Item" is clicked
        try:
            book_pages=int(pages_text_input)
            if title_text_input=="" or author_text_input=="" or pages_text_input=="":
                self.root.ids.output_label.text="All fields must be completed"
            elif book_pages<0:
                self.root.ids.output_label.text="Pages must be positive number"
                self.root.ids.pages_text_input.text = " "#to empty the fields when text and value=' '
                self.root.ids.pages_text_input.value= " "
            else:
                self.book_lists.add_book(title_text_input, author_text_input,pages_text_input)#call the method add_book in BookLists() class in order to add book in the booklist
                self.clear_all()# done to clear the fields after adding a book
                self.book_lists.sort_books()#for sorting the books
                self.on_start()#to reset the required list button
                self.root.ids.output_label.text = "{} by {}, {} pages is added".format(title_text_input, author_text_input,pages_text_input)#overrides the default message and will show that the books is added
        except ValueError:
            if title_text_input == "" or author_text_input == "" or pages_text_input == "":#to make the exception runs, when there is at least one of the text field empty
                self.root.ids.output_label.text = "All fields must b completed"# the exception will be true if at least one field is left blank
            else:#designed for use when the value in the page_text filed has a different type of the input(expected: int, the actual: str)
                self.root.ids.output_label.text = "Please enter a valid a number"
                self.root.ids.pages_text_input.text = ""
                self.root.ids.pages_text_input.value = ""


    def click_list_required(self, instance):#This function is used for clicking the button for the book that is created based on create_widgets() in required books
        title = instance.text #instance.text is the text on the Button, which is the Button in the kv file
        for name_required in self.book_lists.booklists:
            if name_required.title == title:#to check whether the text button you click match the title of the object in booklists(required_name.title)
               change_status = self.book_object.mark_as_complete(name_required.status)#to call method mark_as_completed() in the Book() class
               if change_status == True:
                   name_required.status='c'
               self.on_start()#to make the button immediately dissapear after clicking the button on the required books, otherwise the button will remain
               self.root.ids.output_label.text = "{} to be marked as completed".format(name_required.title)


    def click_list_completed(self,instance):#This function is used for clicking the button for the book created, based on create_widgets() method, in required books
        title = instance.text #instance.text is the text on the Button, which is the Button in the kv file
        for complete_books in self.book_lists.booklists:
           if complete_books.title ==title: #to check if the text-button you click match the title of the object in booklists(completed_name.title)
              self.root.ids.output_label.text = "{} (completed)".format(complete_books)#display the message after you click the button on a list of completed books


    def clear_books(self):#Function is made to clear the field(s) to avoid duplicates in the button
        self.root.ids.entriesBox.clear_widgets()


    def clear_all(self):
        """
        Clear all of the widgets that are children of the "entriesBox" layout widget
        :return:
        """
        self.root.ids.title_text_input.text = ""
        self.root.ids.author_text_input.text = ""
        self.root.ids.pages_text_input.text = ""


    def build(self): #the function is designed to load the .kv file
        self.title = "Reading List 2.0"#used to determine the title of the kv file
        self.root = Builder.load_file('app.kv')#kv file will be loaded
        return self.root

    def on_stop(self):#This function runs when you quit the program
        self.book_lists.saving_books('books.csv')


ReadingListApp().run()



